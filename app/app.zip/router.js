import express from 'express';

import bodyparser from 'body-parser';

const router = new express.Router();

import { getBoroughs, getRestaurant, getRestaurantBybocui } from './controller/controller.js';


/**
 * Déclaration des routes de l'app
 */

router.get("/", getHome);
router.get("/restos", getRestos);
router.get("/explore", getExplore);
router.get("/search_restaurant", getRestaurantName);

/**
 * Déclaration des controlleurs de l'app
 */

/**
 * GET /
 * Page d'accueil
 */
async function getHome(req, res) {
  const boroughs = await getBoroughs();
  res.render('index', { boroughs });
}

function getRestos(req, res) {
  const restaurant = {};
  res.render('restos', { restaurant });
}

async function getExplore(req, res) {
  const boroughs = await getBoroughs();
  const cuisines = await getBoroughs();
  const restaurant = {};
  res.render('explore', {boroughs,cuisines, restaurant })
}
async function getRestaurantName(req, res) {
  const restaurantName = req.query.restaurant_name;
  console.log('Voici restaurantName : ', restaurantName);
  const restaurant = await getRestaurant(restaurantName);
  // let restaurants = await restaurantName;
  res.render('restos', { restaurant });
}

async function getRestaurantBorCui(req, res) {
  const restaurantBorough = req.query.restaurant_borough;
  const restaurantCuisine = req.query.restaurant_cuisine;
  console.log('Voici restaurantBor : ', restaurantBorough);
  const restaurant = await getRestaurantBybocui(restaurantBorough,restaurantCuisine);
  // let restaurants = await restaurantName;
  res.render('explore', { restaurant });
}

// Exporte le routeur pour le fichier principal

export default router;
