
import {
  DB_NAME,
  DB_COLLECTION,
  client
} from '../database.js'

export async function getBoroughs() {
  const db = await client.db(DB_NAME);
  const restaurants = await db.collection(DB_COLLECTION);
  const boroughs = await restaurants.distinct("borough");
  return boroughs.slice(3) || null;
}

//recuperer les cuisines
export async function getCuisines() {
  const db = await client.db(DB_NAME);
  const restaurants = await db.collection(DB_COLLECTION);
  const cuisines = await restaurants.distinct("cuisine");

  return cuisines.slice(3) || null;
}

// Search 
export async function getRestaurant(req) {
  console.log("pName : ", req)
  const db = await client.db(DB_NAME);
  const restaurants = await db.collection(DB_COLLECTION);
  const restaurant = await restaurants.findOne(
    { name: req },
    { _id: 0 }
  )
  console.log("restaurant", restaurant)
  return restaurant || null; 
}

// Search restaurant by boroughs and cuisine 
export async function getRestaurantBybocui(req) {
  //borough=req.params.
  //cuisine=req.params.
  const db = await client.db(DB_NAME);
  const restaurants = await db.collection(DB_COLLECTION);
  const restaurant = await restaurants.find(
    { name: req },
    { _id: 0 }
  )
  console.log("restaurant", restaurant)
  return restaurant || null; 
}

export async function getRestaurantOld(req) {
  console.log("pName : ", req)
  const db = await client.db(DB_NAME);
  const restaurants = await db.collection(DB_COLLECTION);
  const restaurant = await restaurants.findOne(
    { name: 'Morris Park Bake Shop' },
    { _id: 0, name: 1 }
  )
  console.log("restaurant", restaurant)
  return restaurant || null;  
}
